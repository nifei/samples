#ifndef __GAUSSIANBLUROBJECTREGISTER_H__
#define __GAUSSIANBLUROBJECTREGISTER_H__

#define EXTCLASSNAME_GAUSSIANBLUROBJECT "GaussianBlurObject"

class GaussianBlurObjectRegister
{
public:

	static BOOL RegisterGaussianBlurObject();
};

#endif // __GAUSSIANBLUROBJECTREGISTER_H__